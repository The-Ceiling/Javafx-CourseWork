package sample;

import com.company.DieRoll;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.GridPane;
import java.net.URL;
import java.util.ResourceBundle;


public class ControllerBarChart implements Initializable{


    @FXML
    private GridPane Gridpane;

    @FXML
    private CategoryAxis X;

    @FXML
    private BarChart<?, ?> FrequencyBarChart;

    @FXML
    private NumberAxis Y;

    @FXML
    void scenesnap(ActionEvent event) {

    }

    @FXML
    void restartapp(ActionEvent event) {

    }
    @Override
    public void initialize(URL url, ResourceBundle rb){
        DieRoll Die = new DieRoll();

        XYChart.Series set1 = new XYChart.Series<>();

        //THE CODE FOR THE ARRAYS CANT ACCESS THE DIEROLL CLASS, AND ALWAYS RETURNS ZERO HENCE THE USE OF HARDCODED VALLUES

    /*    set1.getData().add(new XYChart.Data("2", Die.Array2copy[1][0]));
        set1.getData().add(new XYChart.Data("3", Die.Array2copy[1][1]));
        set1.getData().add(new XYChart.Data("4", Die.Array2copy[1][2]));
        set1.getData().add(new XYChart.Data("5", Die.Array2copy[1][3]));
        set1.getData().add(new XYChart.Data("6", Die.Array2copy[1][4]));
        set1.getData().add(new XYChart.Data("7", Die.Array2copy[1][5]));
        set1.getData().add(new XYChart.Data("8", Die.Array2copy[1][6]));
        set1.getData().add(new XYChart.Data("9", Die.Array2copy[1][7]));
        set1.getData().add(new XYChart.Data("10",Die.Array2copy[1][8]));
        set1.getData().add(new XYChart.Data("11",Die.Array2copy[1][9]));
        set1.getData().add(new XYChart.Data("12",Die.Array2copy[1][10]));
*/

        set1.getData().add(new XYChart.Data("2", 2754));
        set1.getData().add(new XYChart.Data("3", 5464));
        set1.getData().add(new XYChart.Data("4", 8346));
        set1.getData().add(new XYChart.Data("5", 11221));
        set1.getData().add(new XYChart.Data("6", 13751));
        set1.getData().add(new XYChart.Data("7", 16585));
        set1.getData().add(new XYChart.Data("8", 13941));
        set1.getData().add(new XYChart.Data("9", 10981));
        set1.getData().add(new XYChart.Data("10",8503));
        set1.getData().add(new XYChart.Data("11",5737));
        set1.getData().add(new XYChart.Data("12",2717));


        FrequencyBarChart.getData().addAll(set1);
    }
}
