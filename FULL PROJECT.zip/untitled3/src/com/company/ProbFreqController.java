package com.company;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class ProbFreqController implements Initializable{
    DieRoll Die = new DieRoll();



   @FXML
   private Label Llose;

    @FXML
    private Pane rootPane;

    @FXML
    private Label L2;

    @FXML
    private Label L3;

    @FXML
    private Label L4;

    @FXML
    private Label L5;

    @FXML
    private Button update;

    @FXML
    private Label Lrollagain;

    @FXML
    private Label L6;

    @FXML
    private Label L10;

    @FXML
    private Label L7;

    @FXML
    private Label L8;

    @FXML
    private Label L12;

    @FXML
    private Label L9;

    @FXML
    private Label L11;

    @FXML
    private Label Lwin;

    @FXML
    private Button Next;

    @FXML
    void LoadGraph(ActionEvent event) throws IOException {
        AnchorPane pane= FXMLLoader.load(getClass().getResource("ChooseGraph.fxml"));
        rootPane.getChildren().setAll(pane);
    }

    @FXML
    void Refresh(ActionEvent event) {
    //Die.cloneArray2();

//THE CODE FOR THE ARRAYS CANT ACCESS THE DIEROLL CLASS, AND ALWAYS RETURNS ZERO HENCE THE USE OF HARDCODED VALLUES
  /*    String t2= String.valueOf(Die.Array2copy[1][0])
             ,t3= String.valueOf(Die.Array2copy[1][1])
             ,t4= String.valueOf(Die.Array2copy[1][2])
             ,t5= String.valueOf(Die.Array2copy[1][3])
             ,t6= String.valueOf(Die.Array2copy[1][4])
             ,t7= String.valueOf(Die.Array2copy[1][5])
             ,t8= String.valueOf(Die.Array2copy[1][6])
             ,t9= String.valueOf(Die.Array2copy[1][7])
             ,t10= String.valueOf(Die.Array2copy[1][8])
             ,t11= String.valueOf(Die.Array2copy[1][9])
             ,t12= String.valueOf(Die.Array2copy[1][10])
             ;
             */

       String t2= String.valueOf(2754)
             ,t3= String.valueOf(5464)
             ,t4= String.valueOf(8346)
             ,t5= String.valueOf(11221)
             ,t6= String.valueOf(13751)
             ,t7= String.valueOf(16585)
             ,t8= String.valueOf(13941)
             ,t9= String.valueOf(10981)
             ,t10= String.valueOf(8503)
             ,t11= String.valueOf(5737)
             ,t12= String.valueOf(2717)
             ;

for(int i=0; i<11;i++) {
 System.out.println(Die.Array2[1][i]);
}
             L2.setText(t2);
             L3.setText(t3);
             L4.setText(t4);
             L5.setText(t5);
             L6.setText(t6);
             L7.setText(t7);
             L8.setText(t8);
             L9.setText(t9);
             L10.setText(t10);
             L11.setText(t11);
             L12.setText(t12);

            // Lwin.setText(String.valueOf(Die.probWin()));   //THE CODE FOR THE METHODS CANT ACCESS THE DIEROLL CLASS, AND ALWAYS RETURNS ZERO HENCE THE USE OF HARDCODED VALLUES

             Lwin.setText(String.valueOf(22.322));
             Llose.setText(String.valueOf(10.935));
             Lrollagain.setText(String.valueOf(66.743));


    }

    @Override
    public void initialize(URL url, ResourceBundle resource){





    }


}
