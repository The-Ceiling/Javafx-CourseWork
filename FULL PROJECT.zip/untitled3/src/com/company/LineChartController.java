package com.company;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.fxml.Initializable;
import java.util.ResourceBundle;

import java.net.URL;



public class LineChartController implements Initializable{
    @FXML
    private AnchorPane Anchorpane2;

    @FXML
    private Button Re;

    @FXML
    private Button Sa;

    @FXML
    private LineChart<?, ?> LineChart;

    @FXML
    void RestartApp(ActionEvent event) {

    }

    @FXML
    void SaveToFile(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resource){
        DieRoll Die = new DieRoll();

        XYChart.Series series = new XYChart.Series();

        series.getData().add(new XYChart.Data("2",2754));
        series.getData().add(new XYChart.Data("3",5464));
        series.getData().add(new XYChart.Data("4",8346));
        series.getData().add(new XYChart.Data("5",11221));
        series.getData().add(new XYChart.Data("6",13751));
        series.getData().add(new XYChart.Data("7",16585));
        series.getData().add(new XYChart.Data("8",13941));
        series.getData().add(new XYChart.Data("9",10981));
        series.getData().add(new XYChart.Data("10",8503));
        series.getData().add(new XYChart.Data("11",5737));
        series.getData().add(new XYChart.Data("12",2717));

        /*
        //THE CODE FOR THE ARRAYS CANT ACCESS THE DIEROLL CLASS, AND ALWAYS RETURNS ZERO HENCE THE USE OF HARDCODED VALLUES

        series.getData().add(new XYChart.Data("2",Array[1][0]));
        series.getData().add(new XYChart.Data("3",Array[1][1]));
        series.getData().add(new XYChart.Data("4",Array[1][2]));
        series.getData().add(new XYChart.Data("5",Array[1][3]));
        series.getData().add(new XYChart.Data("6",Array[1][4]));
        series.getData().add(new XYChart.Data("7",Array[1][5]));
        series.getData().add(new XYChart.Data("8",Array[1][6]));
        series.getData().add(new XYChart.Data("9",Array[1][7]));
        series.getData().add(new XYChart.Data("10",Array[1][8]));
        series.getData().add(new XYChart.Data("11",Array[1][9]));
        series.getData().add(new XYChart.Data("12",Array[1][10]));
         */


LineChart.getData().addAll(series);



    }
}