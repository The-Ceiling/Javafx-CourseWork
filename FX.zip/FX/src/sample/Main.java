package com.company;
package sample;

import javafx.scene.layout.StackPane;
import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application {

    Stage window;
    Button button;


    public static void main(String[] args){
        launch(args);
    }

    public void start(Stage primaryStage){
        window = primaryStage;
        window.setTitle("Game of Craps");
        button = new Button("click me");

        button.setOnAction(e -> {
            boolean result;
                   result = com.company.Controller.display("Title of window", " Do you want to begin " );
            System.out.println(result);
        });



        StackPane layout =  new StackPane();
        layout.getChildren().add(button);
        Scene scene = new Scene(layout, 300, 250);
        window.setScene(scene);
        window.show();
    }
}
