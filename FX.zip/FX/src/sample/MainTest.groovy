package sample

class MainTest extends groovy.util.GroovyTestCase {
}
